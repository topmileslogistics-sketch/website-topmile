import Link from "next/link";
import { redirect } from "next/navigation";
import type { Prisma } from "@prisma/client";
import { prisma } from "@/lib/prisma";
import { getSession } from "@/lib/auth";
import { APPLICATION_STATUSES } from "@/lib/validation";
import { AdminShell } from "@/components/admin/AdminShell";
import { STATUS_LABELS, StatusBadge } from "@/components/admin/StatusBadge";
import { cx } from "@/components/ui";

// Applicant data must never be statically rendered or cached.
export const dynamic = "force-dynamic";
export const revalidate = 0;

const PAGE_SIZE = 25;

function formatPhone(digits: string) {
  const d = digits.replace(/\D/g, "").slice(-10);
  return d.length === 10
    ? `(${d.slice(0, 3)}) ${d.slice(3, 6)}-${d.slice(6)}`
    : digits;
}

function formatDate(date: Date) {
  return new Intl.DateTimeFormat("en-US", {
    month: "short",
    day: "numeric",
    year: "numeric",
    hour: "numeric",
    minute: "2-digit",
  }).format(date);
}

export default async function AdminDashboard({
  searchParams,
}: {
  searchParams: Promise<{ q?: string; status?: string; page?: string }>;
}) {
  // Middleware already blocks anonymous requests; this is the check that
  // guarantees no query runs without a valid session.
  const session = await getSession();
  if (!session) redirect("/admin/login");

  const params = await searchParams;
  const query = (params.q ?? "").trim().slice(0, 100);
  const status =
    params.status && APPLICATION_STATUSES.includes(params.status as never)
      ? (params.status as (typeof APPLICATION_STATUSES)[number])
      : undefined;
  const page = Math.max(1, Number.parseInt(params.page ?? "1", 10) || 1);
  const digitsOnly = query.replace(/\D/g, "");

  // Prisma parameterises every value below, so user input cannot alter the SQL.
  const where: Prisma.ApplicationWhereInput = {
    ...(status ? { status } : {}),
    ...(query
      ? {
          OR: [
            { firstName: { contains: query, mode: "insensitive" } },
            { lastName: { contains: query, mode: "insensitive" } },
            { emailNormalized: { contains: query.toLowerCase() } },
            // Only search by phone when the query actually contains digits.
            // A sentinel value here would either match everything or, worse,
            // send a byte Postgres rejects outright.
            ...(digitsOnly.length >= 3
              ? [{ phoneNormalized: { contains: digitsOnly } }]
              : []),
            { city: { contains: query, mode: "insensitive" } },
          ],
        }
      : {}),
  };

  const [applications, total, counts] = await Promise.all([
    prisma.application.findMany({
      where,
      orderBy: { createdAt: "desc" },
      skip: (page - 1) * PAGE_SIZE,
      take: PAGE_SIZE,
      // Only the columns the list needs — the full record stays on the detail
      // page, behind another session check.
      select: {
        id: true,
        firstName: true,
        lastName: true,
        email: true,
        phone: true,
        city: true,
        state: true,
        monthsCdlExperience: true,
        monthsOtrExperience: true,
        status: true,
        createdAt: true,
      },
    }),
    prisma.application.count({ where }),
    prisma.application.groupBy({ by: ["status"], _count: { _all: true } }),
  ]);

  const totalPages = Math.max(1, Math.ceil(total / PAGE_SIZE));
  const countFor = (s: string) =>
    counts.find((c) => c.status === s)?._count._all ?? 0;
  const grandTotal = counts.reduce((sum, c) => sum + c._count._all, 0);

  const buildHref = (overrides: Record<string, string | undefined>) => {
    const sp = new URLSearchParams();
    const next = { q: query, status, page: String(page), ...overrides };
    if (next.q) sp.set("q", next.q);
    if (next.status) sp.set("status", next.status);
    if (next.page && next.page !== "1") sp.set("page", next.page);
    const qs = sp.toString();
    return qs ? `/admin?${qs}` : "/admin";
  };

  return (
    <AdminShell email={session.sub}>
      <div className="flex flex-wrap items-end justify-between gap-4">
        <div>
          <h1 className="text-2xl font-bold tracking-tight text-ink-900">
            Driver applications
          </h1>
          <p className="mt-1 text-sm text-ink-500">
            {grandTotal} total · {countFor("NEW")} new
          </p>
        </div>
        <a
          href={`/api/admin/export${status ? `?status=${status}` : ""}`}
          className="rounded-lg bg-white px-4 py-2.5 text-sm font-semibold text-ink-800 ring-1 ring-inset ring-ink-300 hover:bg-ink-50"
        >
          Export CSV
        </a>
      </div>

      {/* Filters */}
      <div className="mt-6 rounded-xl bg-white p-4 ring-1 ring-ink-200">
        <form method="get" action="/admin" className="flex flex-wrap gap-3">
          <div className="min-w-56 flex-1">
            <label
              htmlFor="q"
              className="block text-xs font-semibold uppercase tracking-wide text-ink-500"
            >
              Search
            </label>
            <input
              id="q"
              name="q"
              type="search"
              defaultValue={query}
              placeholder="Name, email, phone or city"
              maxLength={100}
              className="mt-1 block w-full rounded-lg border-0 px-3 py-2 text-ink-900 ring-1 ring-inset ring-ink-300 focus:ring-2 focus:ring-inset focus:ring-brand-600"
            />
          </div>
          <div>
            <label
              htmlFor="status"
              className="block text-xs font-semibold uppercase tracking-wide text-ink-500"
            >
              Status
            </label>
            <select
              id="status"
              name="status"
              defaultValue={status ?? ""}
              className="mt-1 block rounded-lg border-0 px-3 py-2 text-ink-900 ring-1 ring-inset ring-ink-300 focus:ring-2 focus:ring-inset focus:ring-brand-600"
            >
              <option value="">All statuses</option>
              {APPLICATION_STATUSES.map((s) => (
                <option key={s} value={s}>
                  {STATUS_LABELS[s]} ({countFor(s)})
                </option>
              ))}
            </select>
          </div>
          <div className="flex items-end gap-2">
            <button
              type="submit"
              className="min-h-10 rounded-lg bg-brand-600 px-4 py-2 text-sm font-semibold text-white hover:bg-brand-700"
            >
              Apply
            </button>
            {query || status ? (
              <Link
                href="/admin"
                className="min-h-10 rounded-lg px-4 py-2 text-sm font-semibold text-ink-600 hover:bg-ink-100"
              >
                Clear
              </Link>
            ) : null}
          </div>
        </form>
      </div>

      {/* Results */}
      {applications.length === 0 ? (
        <div className="mt-6 rounded-xl bg-white p-10 text-center ring-1 ring-ink-200">
          <p className="font-semibold text-ink-900">No applications found</p>
          <p className="mt-1 text-sm text-ink-500">
            {query || status
              ? "Try a different search or clear the filters."
              : "New applications will appear here as drivers submit them."}
          </p>
        </div>
      ) : (
        <>
          {/* Table on desktop */}
          <div className="mt-6 hidden overflow-hidden rounded-xl bg-white ring-1 ring-ink-200 md:block">
            <table className="w-full text-left text-sm">
              <caption className="sr-only">
                Driver applications, newest first
              </caption>
              <thead className="bg-ink-50 text-xs uppercase tracking-wide text-ink-500">
                <tr>
                  <th scope="col" className="px-4 py-3 font-semibold">Driver</th>
                  <th scope="col" className="px-4 py-3 font-semibold">Contact</th>
                  <th scope="col" className="px-4 py-3 font-semibold">Location</th>
                  <th scope="col" className="px-4 py-3 font-semibold">Experience</th>
                  <th scope="col" className="px-4 py-3 font-semibold">Status</th>
                  <th scope="col" className="px-4 py-3 font-semibold">Received</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-ink-100">
                {applications.map((app) => (
                  <tr key={app.id} className="hover:bg-ink-50">
                    <td className="px-4 py-3">
                      <Link
                        href={`/admin/applications/${app.id}`}
                        className="font-semibold text-ink-900 underline-offset-2 hover:underline"
                      >
                        {app.firstName} {app.lastName}
                      </Link>
                    </td>
                    <td className="px-4 py-3 text-ink-600">
                      <span className="block">{formatPhone(app.phone)}</span>
                      <span className="block text-xs">{app.email}</span>
                    </td>
                    <td className="px-4 py-3 text-ink-600">
                      {app.city}, {app.state}
                    </td>
                    <td className="px-4 py-3 text-ink-600">
                      {app.monthsCdlExperience} mo CDL ·{" "}
                      {app.monthsOtrExperience} mo OTR
                    </td>
                    <td className="px-4 py-3">
                      <StatusBadge status={app.status} />
                    </td>
                    <td className="px-4 py-3 text-ink-500">
                      {formatDate(app.createdAt)}
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>

          {/* Cards on mobile */}
          <ul className="mt-6 space-y-3 md:hidden">
            {applications.map((app) => (
              <li
                key={app.id}
                className="rounded-xl bg-white p-4 ring-1 ring-ink-200"
              >
                <div className="flex items-start justify-between gap-3">
                  <Link
                    href={`/admin/applications/${app.id}`}
                    className="font-semibold text-ink-900 underline-offset-2 hover:underline"
                  >
                    {app.firstName} {app.lastName}
                  </Link>
                  <StatusBadge status={app.status} />
                </div>
                <p className="mt-2 text-sm text-ink-600">
                  {formatPhone(app.phone)} · {app.city}, {app.state}
                </p>
                <p className="text-sm text-ink-600">{app.email}</p>
                <p className="mt-1 text-xs text-ink-500">
                  {app.monthsCdlExperience} mo CDL · {app.monthsOtrExperience} mo
                  OTR · {formatDate(app.createdAt)}
                </p>
              </li>
            ))}
          </ul>

          {/* Pagination */}
          {totalPages > 1 ? (
            <nav
              aria-label="Pagination"
              className="mt-6 flex items-center justify-between gap-4"
            >
              <PaginationLink
                href={buildHref({ page: String(page - 1) })}
                disabled={page <= 1}
              >
                ← Previous
              </PaginationLink>
              <p className="text-sm text-ink-500">
                Page {page} of {totalPages}
              </p>
              <PaginationLink
                href={buildHref({ page: String(page + 1) })}
                disabled={page >= totalPages}
              >
                Next →
              </PaginationLink>
            </nav>
          ) : null}
        </>
      )}
    </AdminShell>
  );
}

function PaginationLink({
  href,
  disabled,
  children,
}: {
  href: string;
  disabled: boolean;
  children: React.ReactNode;
}) {
  const className = cx(
    "rounded-lg px-4 py-2 text-sm font-semibold ring-1 ring-inset",
    disabled
      ? "pointer-events-none text-ink-400 ring-ink-200"
      : "bg-white text-ink-800 ring-ink-300 hover:bg-ink-50",
  );
  if (disabled) {
    return (
      <span aria-disabled="true" className={className}>
        {children}
      </span>
    );
  }
  return (
    <Link href={href} className={className}>
      {children}
    </Link>
  );
}
